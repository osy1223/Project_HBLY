package edu.bit.board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.bit.board.page.Criteria;
import edu.bit.board.page.PageDTO;
import edu.bit.board.service.BoardService;
import edu.bit.board.vo.BoardVO;
import edu.bit.board.vo.RecVO;
import edu.bit.board.vo.studentVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Controller
@Log4j
@AllArgsConstructor
public class BoardController {
	//������ 5�����ڰ� ������ Auto�ڵ����� �־���
	
	
	//@AllArgsConstructor �̰� ������ 
	//public BoardController (boardservice service){
	//this.service = service �����ڸ� �������� 
	private BoardService service;
	
	@GetMapping("/list") // get ������� �޾Ƽ� getmapping "@RequestMapping" �̰͵� �������
	public void list(Model model) { // �����Ͻ� ������ ���� "BoardService"
	 
		log.info("list");
	   model.addAttribute("list", service.getList());
	}
	
	@GetMapping("/jquarylist") // get ������� �޾Ƽ� getmapping "@RequestMapping" �̰͵� �������
	public void jquarylist(Model model) { // �����Ͻ� ������ ���� "BoardService"
	   log.info("jquarylist");
	   model.addAttribute("jquarylist", service.getList());
	}
	@GetMapping("/content_view") // get ������� �޾Ƽ� getmapping "@RequestMapping" �̰͵� �������
	public String content_view(BoardVO boardVO, Model model) { // �����Ͻ� ������ ���� "BoardService"
	   log.info("content_view");
//	   service.uphit(boardVO);
	   model.addAttribute("content_view", service.get(boardVO.getbId()));
	   
	   return "content_view";
	}
//	private void uphit(BoardVO boardVO) {
//		log.info("hit");
//		((Model) boardVO).addAttribute("content_view", service.get(boardVO.getbId()));
//	}
	@GetMapping("/delete")
	public String delete(BoardVO boardVO, Model model) { 
	   log.info("delete");
	  
	   service.remove(boardVO.getbId());
	   
	   return "redirect:list";
	}
	
	
	 @GetMapping("/write_view") 
	 public String reply_view() {
		 log.info("write_view()");
		
		 return "write_view"; 
	 }
	 
	 @PostMapping("/write")
	 public String write(BoardVO boardVO, Model model) throws Exception{ 
		 log.info("write()");
//		 String bName = String.valueOf(boardVO.getbName());
//		 String bTitle = String.valueOf(boardVO.getbTitle());
//		 String bContent = String.valueOf(boardVO.getbContent());
//		 service.writeBoard(boardVO.getbName(),boardVO.getbTitle(),boardVO.getbContent());
		
		 service.writeBoard(boardVO);
				   
		 return "redirect:list";
	 }
	 
	 @GetMapping("/reply_view") 
	 public String reply_view(BoardVO boardVO, Model model) { 
		 log.info("reply_view()");
		 model.addAttribute("reply_view", service.get(boardVO.getbId()));
		 return "reply_view"; 
	 }
//	 @PostMapping("/reply")
//	 public String reply(BoardVO boardVO, Model model) { 
//		 log.info("reply()");
//		 String bId = String.valueOf(boardVO.getbId());
//		 String bName = String.valueOf(boardVO.getbName());
//		 String bTitle = String.valueOf(boardVO.getbTitle());
//		 String bContent = String.valueOf(boardVO.getbContent());
//		 String bGroup = String.valueOf(boardVO.getbGroup());
//		 String bStep = String.valueOf(boardVO.getbStep());
//		 String bIndent = String.valueOf(boardVO.getbIndent());
//		 service.replyBoard(boardVO.getbId(),boardVO.getbName(),boardVO.getbTitle(),boardVO.getbContent(),boardVO.getbGroup()
//				 ,boardVO.getbStep(),boardVO.getbIndent());
//		 return "redirect:list";
//	 }
	 @PostMapping("/reply")
	 public String reply(BoardVO boardVO, Model model) throws Exception{ 
		 log.info("reply()");
		 service.writeReply(boardVO);
		 return "redirect:list";
	 }
	 
	 @PostMapping("/modify")
	 public String modify(BoardVO boardVO ){
	 log.info("modify()");
	  
	 service.Shape(boardVO);
	 
	 return "redirect:list"; 
	 }
	 
	   //ajax�κ�
	   @RequestMapping("/ajax/list")   
	   public String ajaxList() {
		   
	      log.info("/ajax/list");
	    
	      return "AjaxList";
	   }
	   
	   
	   @ResponseBody
	   @RequestMapping("/restful/recAjax")
	   public Double recArea(RecVO rec) {
		   
		   log.info("recArea");
		   return rec.getArea();
	   }
	   
	   @GetMapping("/restful/Area")
	   public String recArea() {
	      
	      log.info("recArea");
	      return "recAjax";
	   }
	   
	   
	   @ResponseBody
	   @RequestMapping("/restful/studentAvg")
	   public String Student(studentVO stu) {
		   String a = "����"+ stu.getTotal() + '\n' +"���" +stu.getAvg();
		   log.info("studentAvg");
		   return "a";
	   }
	   
	   @GetMapping("/restful/stuavg")
	   public String stuAVG() {
	      
	      log.info("stuavg");
	      return "studentAvg";
	   }
	   
	   
//		@RequestMapping("/AjaxList") // get ������� �޾Ƽ� getmapping "@RequestMapping" �̰͵� �������
//		public void aalist(Model model) { // �����Ͻ� ������ ���� "BoardService"
//		 
//			log.info("ajaxlist");
//		   model.addAttribute("ajaxlist", service.getList());
//		}
	   
	   @GetMapping("/list3")
	    public void list3(Criteria cri, Model model) {   
	       log.info("list3");
	       log.info(cri);
	       model.addAttribute("list", service.getList(cri));   
	       
	       int total = service.getTotal(cri);
	       log.info("total" + total);
	       
	       model.addAttribute("pageMaker", new PageDTO(cri,total));   
	    }
	  
	   
}
	

