package edu.bit.board.service;

import java.util.List;

import edu.bit.board.page.Criteria;
import edu.bit.board.vo.BoardVO;

public interface BoardService {
	
	public List<BoardVO> getList();
	public BoardVO get(int bno);
	public int remove(int bno);

	
	public void writeReply(BoardVO boardVO);
//	public void replyBoard(int getbId, String getbName, String getbTitle, String getbContent, int getbGroup,
//			int getbStep, int getbIndent);
	
	public void writeBoard(BoardVO boardVO);
	//	public void writeBoard(String getbName, String getbTitle, String getbContent);
	public void Shape(BoardVO boardVO);
//	public void uphit(BoardVO boardVO);
	public String deleteBoardVO(int bId);
	
	public int getTotal(Criteria cri);
	public List<BoardVO> getList(Criteria criteria);
}

