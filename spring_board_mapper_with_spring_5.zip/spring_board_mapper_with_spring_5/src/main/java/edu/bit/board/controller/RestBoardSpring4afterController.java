package edu.bit.board.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import edu.bit.board.service.BoardService;
import edu.bit.board.vo.BoardVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@RestController// (controller +@ResponseBody)
@Controller
@Log4j
@AllArgsConstructor //spring 4.0  ���� ���� @controller + @ResponesBody
public class RestBoardSpring4afterController {
	 
	private BoardService boardservice;
	
	@RequestMapping("/restful/after") 
	public List<BoardVO> before(){
		//�ڹٰ�ü�� xml�� �ٲ��ִ� ����(��ü)�� �ִ�
		log.info("/rest/after");
        List <BoardVO> list =  boardservice.getList();
    	
        return list;
	}
	
	 @RequestMapping(value ="/rest/delete/{bId}",method = RequestMethod.DELETE)
		public int restdelete(@PathVariable("bId") int bId) { 
		   
		   return boardservice.remove(bId);
		}
	 @RequestMapping("/rest/index")
		public void list2(Model model) { 
			log.info("index");
			model.addAttribute("index", boardservice.getList());
		}
}
	

