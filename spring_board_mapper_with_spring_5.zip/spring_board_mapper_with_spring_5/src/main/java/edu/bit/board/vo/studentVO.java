package edu.bit.board.vo;

import java.sql.Timestamp;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor 
@AllArgsConstructor
@Getter
@Setter
public class studentVO {

	private double kor;
	private double eng;
	private double mat;
	
	public double getTotal() {
		return kor+eng+mat;
	}
	public double getAvg() {
		return getTotal()/3;
	}
	
	
}
