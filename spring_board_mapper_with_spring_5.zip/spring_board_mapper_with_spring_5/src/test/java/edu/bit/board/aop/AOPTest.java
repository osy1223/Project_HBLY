package edu.bit.board.aop;

import static org.junit.Assert.fail;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import edu.bit.board.service.BoardService;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@Log4j
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml",
						"file:src/main/webapp/WEB-INF/spring/AOP-context.xml"})
public class AOPTest {
	@Inject
	private BoardService service;
	
	@Test
	public void test() {
		
	//	log.info(service.getClass().getName());
		log.info("����Ʈ����");
		log.info(service.getList());
		log.info("����Ʈ��");
	}

}
