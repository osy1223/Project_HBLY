package edu.bit.board.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.bit.board.mapper.BoardMapper;
import edu.bit.board.page.Criteria;
import edu.bit.board.vo.BoardVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j 
@Service
@AllArgsConstructor
public class BoardServiceImpl implements BoardService {
	
	
	private BoardMapper mapper; // DAO �������丮
	
	public List<BoardVO> getList() {
		log.info("getList."); // syso �� ������ �˱�! syso ���� �ȵȴ�.
		
		return mapper.getList();
	}
//	@Override
//	public BoardVO get(int bno) {
//		log.info("get");
//		return mapper.read(bno);
//	}
	@Override
	public BoardVO get(int bno) {
		log.info("get");
	 BoardVO boardVO = 	mapper.read(bno);
						mapper.uphit(bno);
	return boardVO;	
	}
	@Override
	public int remove(int bno) {
		log.info("remove");
		
		return	mapper.delete(bno);
		
	}
//	@Override
//	public void writeBoard(String getbName, String getbTitle, String getbContent) {
//		log.info("write");
//		
//		mapper.write( getbName,  getbTitle,  getbContent);
//		
//	}
	@Override
	public void writeBoard(BoardVO boardVO) {
		mapper.insertboard(boardVO);
		
		
	}
	@Transactional
	@Override
	public void writeReply(BoardVO boardVO) {
		mapper.updateShape(boardVO);
		mapper.insertReply(boardVO);
	}
	@Override
	public void Shape(BoardVO boardVO) {
		mapper.modify(boardVO);
		
	}
	@Override
	public String deleteBoardVO(int bId) {
		// TODO Auto-generated method stub
		return null;
	}
//	@Override
//	public void uphit(BoardVO boardVO) {
//		mapper.Uuphit(boardVO);
//		
//	}
//	@Override
//	public void replyBoard(int getbId, String getbName, String getbTitle, String getbContent, int getbGroup,
//			int getbStep, int getbIndent) {
//		log.info("reply");
//		
//		mapper.reply( getbId,  getbName,  getbTitle,  getbContent,  getbGroup,
//			 getbStep,  getbIndent);
//	}
//	@Override
//	public void Shape(int getbId) {
//		log.info("modiply");
//		
//		mapper.updateShape(getbId);
//		
//	}
	
	   @Override
	   public int getTotal(Criteria cri) {
	      log.info("get total count");
	      return mapper.getTotalCount(cri);
	   }

	   @Override
	   public List<BoardVO> getList(Criteria criteria) {
	      log.info("get List with criteria"  + criteria);
	      return mapper.getListWithPaging(criteria);
	   }
	
}
